# TweetAppWebAPI

https://localhost:44366/User/api/RegisterUser
{  
"first_name":"Sourav",
"last_name":"Kainth",
"gender":"Male",
"dob":"1995-04-01",
"email":"souravkainth@out.com",
"password":"Pass@1" 
}

https://localhost:44366/User/api/UserLogin
{  
"email":"souravkainth@out.com",
"password":"Pass@1" 
}

https://localhost:44366/User/api/ResetPassword
{  
"email":"souravkainth@out.com",
"dob":"1994-12-01",
"password":"Pass@1" 
}

https://localhost:44366/User/api/ChangePassword
{  
"email":"souravkainth@out.com",
"password":"Pass@1",
"newPassword":"Pass@2"
}

https://localhost:44366/User/api/GetAllUsers

https://localhost:44366/User/api/GetUserById/{id}

https://localhost:44366/Tweet/api/GetTweetById/{id}

https://localhost:44366/Tweet/api/GetTweetsByUserId/{id}

https://localhost:44366/Tweet/api/GetAllTweets

https://localhost:44366/Tweet/api/PostTweet
{
"userid":1,
"tweetdesc":"my Tweet"
}
